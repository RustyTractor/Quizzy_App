export const topicsData = [
  { displayed: "Geography", tag: "geography" },
  { displayed: "History", tag: "history" },
  { displayed: "Music", tag: "music" },
  { displayed: "Science", tag: "science" },
];

export const difficultiesData = ["easy", "medium", "hard"];

export const preventBack = () => {
  window.history.forward();
};

export const SpiceyComments = {
  mocking: ["Well that was crap..💩", "How can you be so lame..? 🤡 "],
  notbad: ["Not bad...  🙄", "Fair, but not the best.. 😏 "],
  wow: [
    "You are smarter than the author of the program!!!! 😮 ",
    "Well done!  🤓 ",
  ],
};
